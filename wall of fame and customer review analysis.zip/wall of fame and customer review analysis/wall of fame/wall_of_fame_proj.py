import cv2
from facepplib import FacePP
api_key='xQLsTmMyqp1L2MIt7M3l0h-cQiy0Dwhl'
api_secret='TyBSGw8NBEP9Tbhv_JbQM18mIlorY6-D'
video = cv2.VideoCapture(0)

while True:

    check, frame = video.read()
    cv2.imshow("capturing", frame)
    key = cv2.waitKey(1)
    if key == ord('q'):
        showPic = cv2.imwrite("face1.jpg", frame)
        break


video.release()
cv2.destroyAllWindows()
app_ = FacePP(api_key=api_key,api_secret=api_secret)
print('[Face Comparing]')
img_file1='face1.jpg'
img_file2='face2.jpg'
try:
    cmp_ = app_.compare.get(image_file1=img_file1, image_file2=img_file2)
    print('confidence=', cmp_.confidence)
    if cmp_.confidence > 90:
        print('both faces are same')
    else:
        print('both faces are different')
except:
    print('one or both the images do not contain face')